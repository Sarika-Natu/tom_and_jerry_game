#pragma once

void peripherals_init(void);
